# Request templates

Starter requests in `assets/templates/`. Each file is a complete, runnable
request whose `state` is a placeholder. Paths are relative to this skill's root.

```bash
scripts/jev evaluate assets/templates/fanout_mixed.json -s "Help! My payouts have been failing for 3 days."
```

Or scaffold one for editing:

```bash
scripts/jev init fanout_mixed my_request.json
scripts/jev check my_request.json
scripts/jev evaluate my_request.json --dry-run
```

## When to use which

- **`noul_single.json`** — the minimal yes/no question, with `true`/`false`
  criteria defining what each answer means. Use as the baseline when you need a
  single probability. When several independent yes/no labels may apply, ask one
  Noul per label rather than one multi-label question.

- **`choice_routing.json`** — intent routing over a closed set of handlers,
  including an explicit `other` no-match option. Replace the options with your
  real handlers; keep a no-match outcome so the model can refuse to force-fit,
  and consume the full `probabilities` map, not just the top pick.

- **`score_rubric.json`** — a 4-level rubric. Levels must describe concrete
  situations and stand on their own; the API accepts 2–10 levels. Prefer
  comparable per-item scores when you will rank items against each other.

- **`fanout_mixed.json`** — several independent questions in one call,
  including a speculative question whose premise is stated explicitly
  ("Assuming this message is urgent: ..."). Independent questions run in
  parallel in a single request, which is far cheaper and faster than separate
  calls; code consumes only the answers that apply. Use this as the default
  shape when a workflow needs more than one judgment over the same state.

## Adapting a template

1. Replace `state` with the content to judge. Prefer a named JSON field per
   part of the context (string, object, or array of text values).
2. Edit each question's `instructions` to name the judgment precisely; question
   ids are for your code only and are not sent to the model.
3. Edit `criteria` to define the possible answers. Reference parts of the state
   or of structured instructions with backticked paths.
4. Keep known rules, exact lookups, and execution in code; give the model the
   semantic judgment it owns.

Deeper pattern guidance lives in the live docs cookbooks
(https://docs.typesafe.ai/llms.txt); a dated API contract snapshot is in
`references/REQUEST.md`.
